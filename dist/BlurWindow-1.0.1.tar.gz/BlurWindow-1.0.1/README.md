# PythonBlurBehind

Installation
------------

You can install it with pip::

    python -m pip install BlurWindow


.. code-block:: python

    from blurWindow.blurWindow import blur
    hWnd = self.winId()
    blur(hWnd)

