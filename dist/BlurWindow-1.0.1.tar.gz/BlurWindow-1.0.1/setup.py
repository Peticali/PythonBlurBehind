
from setuptools import setup, find_packages


setup(
    name="BlurWindow",
    version="1.0.1",
    description="Blur PySide windows.",
    url="https://github.com/Peticali/PythonBlurBehind",
    author="Peticali",
    author_email="pedropalmeira68@gmail.com",
    license="MIT",
    packages=['BlurWindow']
    
    

)